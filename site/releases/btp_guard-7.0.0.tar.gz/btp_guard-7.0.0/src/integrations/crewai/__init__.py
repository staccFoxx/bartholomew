"""Bartholomew CrewAI integration package"""
